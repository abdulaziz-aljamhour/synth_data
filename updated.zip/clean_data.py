import pandas as pd
def process_data():
    langs = 'bn hi ur'.split()
    filenames = 'ben hin urd'.split()
    text_files_dict = {lang: filename for lang, filename in zip(langs, filenames)}
    for lang, filename in text_files_dict.items():
        path = f'./data/en-{lang}/'
        filename = f'{filename}.txt'
        headers= f'en_text {lang}_text credit'.split()
        df = pd.read_csv(path+filename, sep='\t', names=headers) \
            .iloc[:, [0, 1]] \
            .drop_duplicates(subset='en_text', keep='first')
        df.tail(200).to_csv(path+f'en-{lang}.csv', index=False)

if __name__ == '__main__':
    print('Attempting to clean data...')
    process_data()
    print('Data cleaned successfully...')