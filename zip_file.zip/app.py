import gradio as gr
import pandas as pd
import os
from pathlib import Path


def prompt_llm(text, model) :
    raise NotImplementedError

def translate_text(text_list: list[str], model='gpt'):
    # translated_text_list = []
    # for text in text_list: # Use list comprehension
        # translated_text = prompt_llm(text, model)
        # translated_text_list.append(translated_text)
    return [
        '', # question
        '', # ans A
        '', # ans B
        '', # ans C
        '', # ans D  
    ]

def approve_action(
    input1,
    input2,
    input3,
    input4,
    input5,
    output1,
    output2,
    output3,
    output4,
    output5,
    translated_language,
    field,
):
    path = Path("./results.xlsx")
    if path.exists():
        df = pd.read_excel(path)
        newframe = pd.DataFrame([{
            "question_english": input1,
            "answer_A_english": input2,
            "answer_B_english": input3,
            "answer_C_english": input4,
            "answer_D_english": input5,
            "question_translated": output1,
            "answer_A_translated": output2,
            "answer_B_translated": output3,
            "answer_C_translated": output4,
            "answer_D_translated": output5,
            "translation_language": translated_language,
            "field": field,
        }])
        df = pd.concat([df , newframe])
        print("saving the follwiong df")
        print(df.tail())
        df.to_excel(path, index=False)
    else:
        df = pd.DataFrame(
            [
                {
                    "question_english": input1,
                    "answer_A_english": input2,
                    "answer_B_english": input3,
                    "answer_C_english": input4,
                    "answer_D_english": input5,
                    "question_translated": output1,
                    "answer_A_translated": output2,
                    "answer_B_translated": output3,
                    "answer_C_translated": output4,
                    "answer_D_translated": output5,
                    "translation_language": translated_language,
                    "field": field,
                }
            ]
        )
        df.to_excel(path, index=False)
    print(f"results saved in {path}")


def translate_action(
    input1,
    input2,
    input3,
    input4,
    input5,
    counter,
    selected_language,
    # output1,
    # output2,
    # output3,
    # output4,
    # output5,
):
    new_counter = counter + 1
    # output1_label = f"Question in {selected_language}"
    # output2_label = f"Answer A in {selected_language}"
    # output3_label = f"Answer B in {selected_language}"
    # output4_label = f"Answer C in {selected_language}"
    # output5_label = f"Answer D in {selected_language}"
    # output1.label = output1_label
    # output2.label = output2_label
    # output3.label = output3_label
    # output4.label = output4_label
    # output5.label = output5_label

    return (input1, input2, input3, input4, input5, str(new_counter), new_counter)


def clear_action():
    return [None] * 10 + [0, 0]


with gr.Blocks() as demo:
    gr.Markdown("<h1 style='text-align: center;'>Smart Translation Agent</h1>")

    with gr.Row():
        with gr.Column(scale=1):
            input1 = gr.Textbox(label="Question in english")
            input2 = gr.Textbox(label="Answer A")
            input3 = gr.Textbox(label="Answer B")
            input4 = gr.Textbox(label="Answer C")
            input5 = gr.Textbox(label="Answer D")

        with gr.Column(scale=1):
            output1 = gr.Textbox(label=f"Question in Urdu", interactive=False)
            output2 = gr.Textbox(label="Answer A in Urdu", interactive=False)
            output3 = gr.Textbox(label="Answer B in Urdu", interactive=False)
            output4 = gr.Textbox(label="Answer C in Urdu", interactive=False)
            output5 = gr.Textbox(label="Answer D in Urdu", interactive=False)
        with gr.Column(scale=1):
            field = gr.Textbox(label="Field")
            approve_button = gr.Button("Approve")
            translate_button = gr.Button("Translate")
            clear_button = gr.Button("Clear")
            counter_display = gr.Textbox(
                label="Translation Count", value="0", interactive=False
            )
            selected_language = gr.Dropdown(
                ["Arabic", "Urdu", "Hindi"],
                label="Language",
                value="Urdu",
                info="What language to translate to?",
                interactive=True,
            )

    translation_counter = gr.State(value=0)
    question_id = gr.State(value=0)

    approve_button.click(
        approve_action,
        inputs=[
            input1,
            input2,
            input3,
            input4,
            input5,
            output1,
            output2,
            output3,
            output4,
            output5,
            selected_language,
            field,
        ],
    )

    translate_button.click(
        translate_action,
        inputs=[
            input1,
            input2,
            input3,
            input4,
            input5,
            translation_counter,
            selected_language,
        ],
        outputs=[
            output1,
            output2,
            output3,
            output4,
            output5,
            counter_display,
            translation_counter,
        ],
    )
    clear_button.click(
        clear_action,
        inputs=[],
        outputs=[
            input1,
            input2,
            input3,
            input4,
            input5,
            output1,
            output2,
            output3,
            output4,
            output5,
            counter_display,
            translation_counter,
        ],
    )

demo.launch()

system_prompt = f"You are an expert in translating text from English to {target_language} your translations will be accurate and will adhere to wisely used terms in the following {field}, You are given a question and a set of answers which you..."
